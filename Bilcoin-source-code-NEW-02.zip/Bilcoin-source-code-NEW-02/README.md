﻿![](share/pixmaps/splashscreen_github.png)




Specifications:
==================

• Name:             Bilcoin

• Ticker:           BILC

• PoW Algorithm:    SHA-256

• P2P Port:         7887

• RPC Port:         7888

• Block Size:       64MB

• Block Time:       1 minute

• Difficulty Time:  1 block

---





• Premine:          2,000,000,000 BILC

• Maturity:         100 Confirmations  

• Max Supply:       2,000,000,000 BILC

---

• 51% attacks resistant

• Segwit BILC adresses start with "B" 

• Legacy BILC adresses start with "b"

• Transaction per second (TPS): 1,066

• Halving time: every 73,600 blocks – 51 days approximately

• Uses the "BilCoinDifficulty" difficulty algorithm (fork of DGW) for a more stable POW mining process over the network


---

Links:
==================

• [Website](https://bilcoin.com/)

• [Explorer](https://explorer.bilcoin.com/)



---

License
-------

Bilcoin is released under the terms of the MIT license. See [COPYING](COPYING) for more
information or see http://opensource.org/licenses/MIT.

